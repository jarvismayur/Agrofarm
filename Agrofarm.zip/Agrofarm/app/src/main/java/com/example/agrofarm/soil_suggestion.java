package com.example.agrofarm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class soil_suggestion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soil_suggestion);
    }
}
