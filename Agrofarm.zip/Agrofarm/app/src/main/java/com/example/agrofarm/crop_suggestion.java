package com.example.agrofarm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class crop_suggestion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_suggestion);
    }
}
